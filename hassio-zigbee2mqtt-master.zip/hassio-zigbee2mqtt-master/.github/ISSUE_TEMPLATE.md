Is your issue about a specific device? It probably belongs in the [zigbee2mqtt issue tracker](https://github.com/Koenkk/zigbee2mqtt). Consider posting your issue there first.
